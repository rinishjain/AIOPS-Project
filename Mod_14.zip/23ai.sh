#!/usr/bin/bash
sudo podman stop 23ai
sudo podman rm 23ai
sudo podman rmi  --force $(podman images -a -q)

sudo rm -rf /home/opc/oradata

# Run the Oracle Database Free Edition container
echo "Running Oracle Database container..."
sudo podman run -d \
    --name 23ai \
    --network=host \
    -e ORACLE_PWD=database123 \
    container-registry.oracle.com/database/free:23.9.0.0-amd64

# Wait for Oracle Container to start
echo "Waiting for Oracle container to initialize..."
sleep 20

# --- Wait for CDB root (FREE) ---
# Checking if FREE (CDB root) is registered
echo "$(date '+%Y-%m-%d %H:%M:%S') Checking if FREE (CDB root) is registered..."
MAX_RETRIES=20
for i in $(seq 1 $MAX_RETRIES); do
  if sudo podman exec 23ai lsnrctl status | grep -q "FREE "; then
    echo "$(date '+%Y-%m-%d %H:%M:%S') FREE service is registered with the listener."
    break
  fi
  echo "$(date '+%Y-%m-%d %H:%M:%S') [$i/$MAX_RETRIES] Waiting for FREE service..."
  sleep 10
done

if ! sudo podman exec 23ai lsnrctl status | grep -q "FREEPDB1"; then
  echo "$(date '+%Y-%m-%d %H:%M:%S') FREEPDB1 not registered after $MAX_RETRIES attempts. Forcing it open..."
  sudo podman exec 23ai bash -lc "echo exit | sqlplus -S / as sysdba <<EOF
  ALTER SYSTEM SET LOCAL_LISTENER = '(ADDRESS=(PROTOCOL=TCP)(HOST=127.0.0.1)(PORT=1521))' scope=both;
  ALTER SYSTEM REGISTER;
  ALTER PLUGGABLE DATABASE ALL OPEN;
  ALTER PLUGGABLE DATABASE ALL SAVE STATE;
  EXIT;
EOF"
  echo "$(date '+%Y-%m-%d %H:%M:%S') Forced FREEPDB1 open and saved state. Continuing setup..."
fi


# Run the SQL commands to configure the PDB
echo "Configuring Oracle database in PDB (freepdb1)..."
sudo podman exec -i 23ai bash <<EOF
sqlplus -S / as sysdba <<EOSQL
-- ensure PDB is open and switch context
-- ALTER PLUGGABLE DATABASE FREEPDB1 OPEN IF NOT EXISTS;
ALTER SESSION SET CONTAINER=FREEPDB1;
CREATE BIGFILE TABLESPACE tbs2 DATAFILE 'bigtbs_f2.dbf' SIZE 1G AUTOEXTEND ON NEXT 32M MAXSIZE UNLIMITED EXTENT MANAGEMENT LOCAL SEGMENT SPACE MANAGEMENT AUTO;
CREATE UNDO TABLESPACE undots2 DATAFILE 'undotbs_2a.dbf' SIZE 1G AUTOEXTEND ON RETENTION GUARANTEE;
CREATE TEMPORARY TABLESPACE temp_demo TEMPFILE 'temp02.dbf' SIZE 1G REUSE AUTOEXTEND ON NEXT 32M MAXSIZE UNLIMITED EXTENT MANAGEMENT LOCAL UNIFORM SIZE 1M;
CREATE USER vector IDENTIFIED BY vector DEFAULT TABLESPACE tbs2 QUOTA UNLIMITED ON tbs2;
GRANT DB_DEVELOPER_ROLE TO vector;
EXIT;
EOSQL
EOF

# Reconnect to CDB root to apply system-level changes
echo "Switching to CDB root for system-level changes..."
sudo podman exec -i 23ai bash <<EOF
sqlplus -S / as sysdba <<EOSQL
CREATE PFILE FROM SPFILE;
ALTER SYSTEM SET vector_memory_size = 512M SCOPE=SPFILE;
SHUTDOWN IMMEDIATE;
STARTUP;
-- Re-open PDBs after restart and save state again
ALTER PLUGGABLE DATABASE ALL OPEN;
ALTER PLUGGABLE DATABASE ALL SAVE STATE;
ALTER SYSTEM REGISTER;
EXIT;
EOSQL
EOF

echo "Final listener check:"
sudo podman exec -i 23ai bash -lc "lsnrctl services"

# Wait for Oracle to restart and apply memory changes
sleep 10